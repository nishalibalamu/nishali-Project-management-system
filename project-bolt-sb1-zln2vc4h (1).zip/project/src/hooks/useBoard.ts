import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import type { Column, Task, Comment } from '../types';

export function useBoard(projectId: string) {
  const [columns, setColumns] = useState<Column[]>([]);
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (!projectId || !supabase) {
      fetchBoardData();
      setupRealtimeSubscription();
    }
  }, [projectId]);

  const fetchBoardData = async () => {
    if (!supabase) return;
    
    try {
      const [columnsResponse, tasksResponse] = await Promise.all([
        supabase
          .from('columns')
          .select('*')
          .eq('project_id', projectId)
          .order('position'),
        supabase
          .from('tasks')
          .select('*')
          .eq('project_id', projectId)
          .order('position')
      ]);

      if (columnsResponse.error) throw columnsResponse.error;
      if (tasksResponse.error) throw tasksResponse.error;

      setColumns(columnsResponse.data || []);
      setTasks(tasksResponse.data || []);
    } catch (error) {
      console.error('Error fetching board data:', error);
    } finally {
      setLoading(false);
    }
  };

  const setupRealtimeSubscription = () => {
    const tasksSubscription = supabase
      .channel('tasks_changes')
      .on('postgres_changes', 
        { event: '*', schema: 'public', table: 'tasks', filter: `project_id=eq.${projectId}` },
        (payload) => {
          if (payload.eventType === 'INSERT') {
            setTasks(prev => [...prev, payload.new as Task]);
          } else if (payload.eventType === 'UPDATE') {
            setTasks(prev => prev.map(task => 
              task.id === payload.new.id ? payload.new as Task : task
            ));
          } else if (payload.eventType === 'DELETE') {
            setTasks(prev => prev.filter(task => task.id !== payload.old.id));
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(tasksSubscription);
    };
  };

  const createTask = async (title: string, columnId: string) => {
    try {
      const position = tasks.filter(t => t.column_id === columnId).length;
    if (!supabase) throw new Error('Supabase not configured');
    
      
      const { data, error } = await supabase
        .from('tasks')
        .insert([{
          title,
          column_id: columnId,
          project_id: projectId,
          position,
          priority: 'medium'
        }])
        .select()
        .single();

      if (error) throw error;
      return { data, error: null };
    } catch (error) {
      console.error('Error creating task:', error);
      return { data: null, error };
    }
  };

  const updateTask = async (taskId: string, updates: Partial<Task>) => {
    try {
      const { data, error } = await supabase
        .from('tasks')
        .update(updates)
        .eq('id', taskId)
        .select()
        .single();

      if (error) throw error;
    if (!supabase) throw new Error('Supabase not configured');
    
      return { data, error: null };
    } catch (error) {
      console.error('Error updating task:', error);
      return { data: null, error };
    }
  };

  const moveTask = async (taskId: string, newColumnId: string, newPosition: number) => {
    try {
      const { error } = await supabase
        .from('tasks')
        .update({ column_id: newColumnId, position: newPosition })
        .eq('id', taskId);

      if (error) throw error;
    } catch (error) {
      console.error('Error moving task:', error);
    }
  };

  return {
    columns,
    tasks,
    loading,
    createTask,
    updateTask,
    moveTask,
    refetch: fetchBoardData,
  };
}