import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import type { Project } from '../types';

export function useProjects() {
  const [projects, setProjects] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchProjects();
  }, []);

  const fetchProjects = async () => {
    try {
      const { data, error } = await supabase
        .from('projects')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setProjects(data || []);
    } catch (error) {
      console.error('Error fetching projects:', error);
    } finally {
      setLoading(false);
    }
  };

  const createProject = async (name: string, description?: string, color = '#6366F1') => {
    if (!supabase) return;
    
    try {
      const { data, error } = await supabase
        .from('projects')
        .insert([{ name, description, color }])
        .select()
        .single();

      if (error) throw error;

      // Create default columns for the new project
      await supabase.from('columns').insert([
        { name: 'To Do', project_id: data.id, position: 0, color: '#94A3B8' },
        { name: 'In Progress', project_id: data.id, position: 1, color: '#F59E0B' },
        { name: 'Done', project_id: data.id, position: 2, color: '#10B981' },
      ]);

      setProjects(prev => [data, ...prev]);
      return { data, error: null };
    } catch (error) {
      console.error('Error creating project:', error);
      return { data: null, error };
    }
  };

  return {
    projects,
    loading,
    createProject,
    refetch: fetchProjects,
  };
}