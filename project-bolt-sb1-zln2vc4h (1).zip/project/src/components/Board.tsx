import React, { useState } from 'react';
import { ArrowLeft, Plus, MoreHorizontal } from 'lucide-react';
import { DndContext, DragEndEvent, DragOverlay, DragStartEvent } from '@dnd-kit/core';
import { SortableContext, verticalListSortingStrategy } from '@dnd-kit/sortable';
import { useBoard } from '../hooks/useBoard';
import { Column } from './Column';
import { TaskCard } from './TaskCard';
import { CreateTaskModal } from './CreateTaskModal';
import type { Task } from '../types';

interface BoardProps {
  projectId: string;
  onBack: () => void;
}

export function Board({ projectId, onBack }: BoardProps) {
  const { columns, tasks, loading, createTask, moveTask } = useBoard(projectId);
  const [showCreateTask, setShowCreateTask] = useState(false);
  const [selectedColumnId, setSelectedColumnId] = useState<string>('');
  const [activeTask, setActiveTask] = useState<Task | null>(null);

  const handleDragStart = (event: DragStartEvent) => {
    const task = tasks.find(t => t.id === event.active.id);
    setActiveTask(task || null);
  };

  const handleDragEnd = (event: DragEndEvent) => {
    setActiveTask(null);
    const { active, over } = event;

    if (!over) return;

    const taskId = active.id as string;
    const overId = over.id as string;

    // Find the column the task is being dropped on
    let newColumnId: string;
    let newPosition: number;

    if (columns.some(col => col.id === overId)) {
      // Dropped on a column
      newColumnId = overId;
      newPosition = tasks.filter(t => t.column_id === overId).length;
    } else {
      // Dropped on a task
      const overTask = tasks.find(t => t.id === overId);
      if (!overTask) return;
      
      newColumnId = overTask.column_id;
      newPosition = overTask.position;
    }

    moveTask(taskId, newColumnId, newPosition);
  };

  const handleCreateTask = async (title: string, description: string) => {
    await createTask(title, selectedColumnId);
    setShowCreateTask(false);
  };

  const openCreateTask = (columnId: string) => {
    setSelectedColumnId(columnId);
    setShowCreateTask(true);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-500"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-indigo-50">
      <div className="border-b border-gray-200 bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <button
                onClick={onBack}
                className="text-gray-600 hover:text-gray-900 transition-colors"
              >
                <ArrowLeft className="w-6 h-6" />
              </button>
              <h1 className="text-2xl font-bold text-gray-900">Project Board</h1>
            </div>
            <button className="text-gray-600 hover:text-gray-900 transition-colors">
              <MoreHorizontal className="w-6 h-6" />
            </button>
          </div>
        </div>
      </div>

      <div className="p-6">
        <DndContext onDragStart={handleDragStart} onDragEnd={handleDragEnd}>
          <div className="flex gap-6 overflow-x-auto pb-6">
            {columns.map((column) => (
              <SortableContext
                key={column.id}
                items={tasks.filter(t => t.column_id === column.id).map(t => t.id)}
                strategy={verticalListSortingStrategy}
              >
                <Column
                  column={column}
                  tasks={tasks.filter(t => t.column_id === column.id)}
                  onCreateTask={() => openCreateTask(column.id)}
                />
              </SortableContext>
            ))}
          </div>

          <DragOverlay>
            {activeTask ? <TaskCard task={activeTask} isDragging /> : null}
          </DragOverlay>
        </DndContext>
      </div>

      {showCreateTask && (
        <CreateTaskModal
          onClose={() => setShowCreateTask(false)}
          onCreate={handleCreateTask}
        />
      )}
    </div>
  );
}