import React from 'react';
import { Plus } from 'lucide-react';
import { useDroppable } from '@dnd-kit/core';
import { TaskCard } from './TaskCard';
import type { Column as ColumnType, Task } from '../types';

interface ColumnProps {
  column: ColumnType;
  tasks: Task[];
  onCreateTask: () => void;
}

export function Column({ column, tasks, onCreateTask }: ColumnProps) {
  const { setNodeRef } = useDroppable({
    id: column.id,
  });

  return (
    <div className="flex-shrink-0 w-80">
      <div className="bg-white rounded-2xl shadow-sm border border-gray-100 h-fit">
        <div className="p-4 border-b border-gray-100">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div 
                className="w-3 h-3 rounded-full"
                style={{ backgroundColor: column.color }}
              ></div>
              <h3 className="font-semibold text-gray-900">{column.name}</h3>
              <span className="bg-gray-100 text-gray-600 text-sm px-2 py-1 rounded-full">
                {tasks.length}
              </span>
            </div>
            <button
              onClick={onCreateTask}
              className="text-gray-400 hover:text-gray-600 transition-colors"
            >
              <Plus className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div 
          ref={setNodeRef}
          className="p-4 space-y-3 min-h-32"
        >
          {tasks.map((task) => (
            <TaskCard key={task.id} task={task} />
          ))}
        </div>
      </div>
    </div>
  );
}