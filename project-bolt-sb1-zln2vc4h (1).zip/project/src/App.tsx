import React, { useState } from 'react';
import { useAuth } from './hooks/useAuth';
import { supabase } from './lib/supabase';
import { AuthForm } from './components/AuthForm';
import { ProjectList } from './components/ProjectList';
import { Board } from './components/Board';
import { LogOut, User } from 'lucide-react';

type View = 'projects' | 'board';
import { AlertCircle } from 'lucide-react';

function App() {
  const { user, loading, signOut } = useAuth();
  const [currentView, setCurrentView] = useState<View>('projects');
  const [selectedProjectId, setSelectedProjectId] = useState<string>('');

  const handleSelectProject = (projectId: string) => {
    setSelectedProjectId(projectId);
    setCurrentView('board');
  };

  const handleBackToProjects = () => {
    setCurrentView('projects');
    setSelectedProjectId('');
  };

  const handleSignOut = async () => {
    await signOut();
    setCurrentView('projects');
    setSelectedProjectId('');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-indigo-500"></div>
      </div>
    );
  }

  // Show configuration message if Supabase is not configured
  if (!supabase) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50 flex items-center justify-center p-4">
        <div className="bg-white rounded-lg shadow-lg p-8 max-w-md w-full text-center">
          <AlertCircle className="w-12 h-12 text-amber-500 mx-auto mb-4" />
          <h2 className="text-xl font-semibold text-gray-900 mb-2">
            Supabase Configuration Required
          </h2>
          <p className="text-gray-600 mb-4">
            To use this application, you need to configure your Supabase connection.
          </p>
          <div className="bg-gray-50 rounded-lg p-4 text-left text-sm">
            <p className="font-medium text-gray-900 mb-2">Setup Instructions:</p>
            <ol className="list-decimal list-inside space-y-1 text-gray-700">
              <li>Click "Connect to Supabase" in the top right</li>
              <li>Create a new Supabase project</li>
              <li>Copy your project URL and anon key</li>
              <li>The app will automatically configure itself</li>
            </ol>
          </div>
        </div>
      </div>
    );
  }

  if (!user) {
    return <AuthForm />;
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Top Navigation */}
      <div className="bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 bg-gradient-to-r from-indigo-500 to-purple-600 rounded-lg flex items-center justify-center">
                <div className="w-4 h-4 bg-white rounded-sm"></div>
              </div>
              <span className="text-xl font-bold text-gray-900">ProjectFlow</span>
            </div>
            
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <User className="w-4 h-4" />
                {user.email}
              </div>
              <button
                onClick={handleSignOut}
                className="text-gray-600 hover:text-gray-900 transition-colors flex items-center gap-2"
              >
                <LogOut className="w-4 h-4" />
                Sign Out
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      {currentView === 'projects' ? (
        <ProjectList onSelectProject={handleSelectProject} />
      ) : (
        <Board projectId={selectedProjectId} onBack={handleBackToProjects} />
      )}
    </div>
  );
}

export default App;